import React, { Component } from "react";

// class 
class AppClass extends Component{
    title = "Class Component";
    justiceleague = ["Batman","Superman","Flash", "Wonder Women", "Cyborg", "Aquaman"]
    render(){
        return <React.Fragment>
                <h1>Welcome to React Training : { this.title }</h1>
                <ol>
                    { this.justiceleague.map((val,idx) => <li key={idx}>{ val }</li>)}
                </ol>
               </React.Fragment>
    }
}

export default AppClass;