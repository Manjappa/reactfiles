import ReactDOM from "react-dom/client";
import AppFun from "./appfun";
import AppClass from "./appclass";


ReactDOM
.createRoot(document.getElementById("root"))
.render(<> <AppClass/> <AppFun/> </>)