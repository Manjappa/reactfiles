import React from "react";

// function
let AppFun = function(){
    var title = "Fun Comp";
    var avengers = ['Ironman', 'Hulk', 'Thor', 'Black Widow', 'Black Panther'];
    return <React.Fragment>
                <h1>Welcome to React Training : { title } </h1>
                <ul>
                    {[
                        <li key={1}>{avengers[0]}</li>,
                        <li key={2}>{avengers[1]}</li>,
                        <li key={3}>{avengers[2]}</li>,
                        <li key={4}>{avengers[3]}</li>,
                        <li key={5}>{avengers[4]}</li>
                    ]}
                </ul>
                <hr/>
                <ol>
                    { avengers.map( (val, idx) => <li key={idx}>{ val }</li> ) }
                </ol>
           </React.Fragment>
}

export default AppFun;