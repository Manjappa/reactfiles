import React,{ Component } from "react";
import ListComp from "./list";

class App extends Component{
    avengers = [];
    justiceleague = [];
    indicheroes = [];
    avengerinput = React.createRef();
    jlinput = React.createRef();
    ihinput = React.createRef();
    index = [];
    constructor(){
        super();
        this.index = ["Avenger", "Justice League", "Indic Heroes"]
    }
    render(){
        return <div>
                    <h1>Welcome to React Workshop</h1>
                    <h2>Lists</h2>
                    <label htmlFor="avenger">Avengers</label>
                    <input ref={this.avengerinput} id="avenger" type="text" />
                    <button onClick={ this.avengerHandler }>Add Avenger</button>
                    <br />
                    <br />
                    <label htmlFor="justiceleague">Justice League</label>
                    <input ref={this.jlinput} id="justiceleague" type="text" />
                    <button onClick={ this.justiceLeagueHandler }>Add Justice League</button>
                    <br />
                    <br />
                    <label htmlFor="indichero" >Indic Heroes</label>
                    <input ref={this.ihinput} id="indichero" type="text" />
                    <button onClick={this.indicHeroHandler}>Add Indic Hero</button>
                    <ListComp version="101" title={this.index[0]} list={this.avengers}/>
                    <ListComp version="102" title={this.index[1]} list={this.justiceleague}/>
                    <ListComp title={this.index[2]} list={this.indicheroes}/>
               </div>
    }
    avengerHandler = () => {
       // alert("do you want to add an avenger")
       // alert(this.avengerinput.current.value);
       this.avengers.push(this.avengerinput.current.value);
       console.log(this.avengers.length);
       this.forceUpdate();
    }
    justiceLeagueHandler = () => {
       this.justiceleague.push(this.jlinput.current.value);
       this.forceUpdate();
    }
    indicHeroHandler = () => {
       this.indicheroes.push(this.ihinput.current.value);
       this.forceUpdate();
    }
}

export default App;