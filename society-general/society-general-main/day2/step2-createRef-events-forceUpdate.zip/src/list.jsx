import { Component } from "react";

class ListComp extends Component{
    render(){
        return <div>{/* props are immutable */}
                    <h2>{ this.props.title } : { this.props.version || 0 }</h2>
                    <ol>
                        { this.props.list.map((val,idx) => <li key={idx}>{ val }</li>)}
                    </ol>
                </div>
    }
}

export default ListComp