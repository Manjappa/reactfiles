function init(){
    document.getElementsByTagName("h1")[0].innerText = "Welcome to your life";
}