class Person{
    ability = "i can walk";
    constructor(nability){
        this.ability = nability;
    }
    sayability(){
        return this.ability;
    }
}

export default Person;