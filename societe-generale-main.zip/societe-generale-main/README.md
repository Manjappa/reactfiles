# Societe Generale
training files for react


## Interim Feedback 
<a href="https://docs.google.com/forms/d/e/1FAIpQLSe60eZX6QngONfFnM5dn7JHbgjWGwZ5JmlOIbMBlgG7xr1zeg/viewform?vc=0&c=0&w=1&flr=0"> Link </a>
